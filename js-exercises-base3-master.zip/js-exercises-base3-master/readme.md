# Exercices JavaScript - Partie 3

**IMPORTANT**
Toutes les ressources aux exercices seront fourni quand cela sera nécessaire.  
Pour la sécurité de votre code, à chaque formulaire verifiez que ce qui est saisi correspond à ce qui est attendu.

##Exercice 1
Dans le fichier HTML fourni, au survol de l'image ajouter une bordure de 3px rouge et la retirer quand la souris ne la survol plus.

##Exercice 2
Dans le fichier HTML fourni, faire afficher ou masquer le texte en fonction de l'ancre.

##Exercice 3
Dans le fichier HTML fourni, changer la couleur du texte en fonction du bouton choisi.

##Exercice 4
Dans le fichier HTML fourni, mettre les bordures des inputs en rouge si les mots de passe sont différents. Sinon les mettre en vert.
